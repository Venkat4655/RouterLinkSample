# ej2-ng-grid-Customize-row

Customizing row based on the row cell value.

## Requirement

Strike through the row based on the row cell value.

## Solution 

Row can be customized using `rowDataBound` event of Grid Component that triggers for every row.

## Installing

To install all dependent packages, use the below command

```
npm install
```

## Run sample

To run the sample, use the below command

```
npm start
```