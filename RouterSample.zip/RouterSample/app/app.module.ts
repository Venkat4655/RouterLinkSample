import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { GridModule,  ExcelExportService, VirtualScrollService,PdfExportService, PageService,FilterService,GroupService, SortService, EditService, ToolbarService } from '@syncfusion/ej2-ng-grids';
import { ButtonModule } from '@syncfusion/ej2-ng-buttons';
import { AppComponent }  from './app.component';
import { SecondComponent } from './second.component';
import { RouterModule, Routes } from '@angular/router';
const appRoutes: Routes = [
  { path: 'second', component: SecondComponent } 
];

@NgModule({
  imports:      [ BrowserModule, GridModule, ButtonModule,  RouterModule.forRoot(
      appRoutes,
      { useHash: true } // <-- debugging purposes only
    ) ],
  declarations: [ AppComponent,SecondComponent ],
  bootstrap:    [ AppComponent ],
  providers: [PageService, ToolbarService,  VirtualScrollService,ExcelExportService, PdfExportService, FilterService,GroupService,SortService, EditService, ToolbarService]
})
export class AppModule { }
