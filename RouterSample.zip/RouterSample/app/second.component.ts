import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-container',
    template: `Navigate page`
})
export class SecondComponent implements OnInit {

    ngOnInit(): void {
        
    }
}